package com.sneh.quizzard.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sneh.quizzard.entities.quizzardEntity;
import com.sneh.quizzard.repositories.QuizzardRepository;

@RestController
public class quizzardController {

	@Autowired
	QuizzardRepository repo;
	
	@PostMapping("/addUser")
	public quizzardEntity saveData(quizzardEntity obj) {
		repo.save(obj);
		System.out.println("user is saved ");
		return obj;
	}
	
	@GetMapping("/getUsers")
	public List<quizzardEntity> getData(){
		return repo.findAll();
	}
	
	@GetMapping("/deleteUser/{user_id}")
	public List<quizzardEntity> deleteData(@PathVariable("user_id") int user_id){
		repo.deleteById(user_id);
		return repo.findAll();
	}
	
}
