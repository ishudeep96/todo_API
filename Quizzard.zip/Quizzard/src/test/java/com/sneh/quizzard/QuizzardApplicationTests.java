package com.sneh.quizzard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizzardApplicationTests {

	@Test
	void contextLoads() {
	}

}
